
const Transactions = () => {
    return (
        <div className="">Transactions</div>
    )
}

export default Transactions