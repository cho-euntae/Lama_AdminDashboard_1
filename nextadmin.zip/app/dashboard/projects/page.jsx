
const Projects = () => {
    return (
        <div className="">Projects</div>

    )
}

export default Projects